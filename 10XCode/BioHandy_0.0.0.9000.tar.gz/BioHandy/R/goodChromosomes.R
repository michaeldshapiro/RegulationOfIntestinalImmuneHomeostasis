
## ###################################################
#' The cannonical chromosomes
#'
#' In mouse this is 1 through 19, X, Y, and M
#' In humans this is 1 through 22, X, Y and M
#'
#' @param organism - 'mouse' or 'human'
#' @return the list of chromosomes
#' @export
goodChromosomes = function(organism)
{
    stopifnot(organism %in% c('mouse','human'))

    if(organism == 'mouse')
    {
        numbered = 19
    } else {
        numbered = 22
    }

    return(paste0('chr',c(1:numbered,'X','Y','M')))
}


## ###################################################
#' Set the seqlevels
#'
#' This takes an object with seqlevels and a choice of organism and
#' restricts the seqlevels to the good chromosomes
#'
#' @param x The object
#' @param organism The choice of organism
#' @return x with its seqlevels restricted to the good chromosomes
#' @importFrom GenomeInfoDb seqlengths
#' @export
setSeqlevels = function(x,organism)
{
    
    seqlevels(x,pruning.mode='coarse') = goodChromosomes(organism)

    return(x)
}
