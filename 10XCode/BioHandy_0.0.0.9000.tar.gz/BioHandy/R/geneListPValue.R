
## ###################################################
#' A function to compute p-values for gene list overlaps
#'
#' This takes the sizes of two gene lists and their overlaps and
#' estimates a p value for the overlap when taken against a given
#' background.
#'
#' @param A - The size of the first list
#' @param B - The size of the second list
#' @param C - The size of their overlap
#' @param background - The size of the background list, defaults to
#'     25000.
#' @return The p-value
#' @export
geneListPValue = function(A,B,C,background=25000)
{
    M = matrix(0,nrow=2,ncol=2)
    
    M[1,1] = background - A
    M[1,2] = A
    M[2,1] = B - C
    M[2,2] = C

    

    f = fisher.test(M,alternative='greater')

    return(f$p.value)
}

