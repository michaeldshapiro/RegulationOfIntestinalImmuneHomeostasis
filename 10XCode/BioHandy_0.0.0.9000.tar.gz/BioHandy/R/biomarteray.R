

#' For converting ENSMUSG to gene symbol:
#'
#' This function is a wrapper around biomaRt to simplify
#' conversion of ENSMUSG gene names to gene symbols.
#' @param ensmusg a vector of genes in ENSMUSG format
#'
#' @importFrom biomaRt useMart
#' @importFrom biomaRt getBM
#' @importFrom biomaRt getLDS
#' @export
ENSMUSGtoGeneSymbol = function(ensmusg)
{
    ensembl = biomaRt::useMart('ensembl', dataset='mmusculus_gene_ensembl')

    geneTable = biomaRt::getBM(attributes =c('ensembl_gene_id',
                                             'external_gene_name'),
                               filters='ensembl_gene_id',
                               values=ensmusg,
                               mart=ensembl)
    geneTable = geneTable[!duplicated(geneTable$ensembl_gene_id),]
    rownames(geneTable) = geneTable$ensembl_gene_id

    geneSymbols = geneTable[ensmusg,]$external_gene_name
    names(geneSymbols) = ensmusg

    return(geneSymbols)
}

#' For converting entrezgene_id to gene symbol:
#'
#' This function is a wrapper around biomaRt to simplify
#' conversion of entrez gene id to gene symbols.
#' @param entrez a vector of genes in ENSMUSG format
#'
#' @export
entrezToGeneSymbol = function(entrez)
{
    ensembl = biomaRt::useMart('ensembl', dataset='mmusculus_gene_ensembl')

    geneTable = biomaRt::getBM(attributes =c('entrezgene_id',
                                             'external_gene_name'),
                               filters='entrezgene_id',
                               values=entrez,
                               mart=ensembl)

    geneTable = geneTable[!duplicated(geneTable$ensembl_gene_id),]
    rownames(geneTable) = geneTable$ensembl_gene_id

    geneSymbols = geneTable[ensmusg,]$external_gene_name
    names(geneSymbols) = ensmusg

    return(geneSymbols)
}


#' For converting gene symbol to ENSMUSG
#'
#' This function is a wrapper around biomaRt to simplify
#' conversion of gene symbol to ENSMUSG names.
#' @param geneSymbol a vector of gene symbols
#'
#' @export
geneSymbolToENSMUSG = function(geneSymbol)
{
    ensembl = biomaRt::useMart('ensembl', dataset='mmusculus_gene_ensembl')

    geneTable = biomaRt::getBM(attributes =c('ensembl_gene_id',
                                             'external_gene_name'),
                               filters='external_gene_name',
                               values=geneSymbol,
                               mart=ensembl)
    ensmusg = geneSymbol
    names(ensmusg) = geneSymbol
    for(i in 1:length(geneSymbol))
    {
        gene = geneSymbol[i]
        idx = geneTable$external_gene_name == gene
        tag = paste(geneTable$ensembl_gene_id[idx],collapse=' ')
        ensmusg[i] = tag
    }
    
    return(ensmusg)
}



## ###################################################
#' For converting gene ENSMUSG to entrez gene id
#'
#' This function is a wrapper around biomaRt to simplify
#' conversion of gene symbol to ENSMUSG names.
#' @param ensmusg a vector of ensembl gene ids
#'
#' @export

ensemblToEntrez = function(ensmusg)
{
    ensembl = biomaRt::useMart('ensembl', dataset='mmusculus_gene_ensembl')
    
    geneTable = biomaRt::getBM(attributes=c('entrezgene_id','ensembl_gene_id'),
                               filters='ensembl_gene_id',
                               values=ensmusg,
                               mart=ensembl)

    geneTable = geneTable[!duplicated(geneTable$ensembl_gene_id),]
                               
    rownames(geneTable) = geneTable$ensembl_gene_id
    entrez = geneTable[ensmusg,]$entrezgene_id
    names(entrez) = ensmusg
    entrez = as.character(entrez)

    return(entrez)
}


## ###################################################
#' For converting mouse genes to human genes
#'
#' This uses biomaRt to produce a dictionary from the given mouse
#' genes to their human equivalents.
#'
#' @param mouseGenes - a character vector of mouse gene symbols
#'
#' @return This returns a named character vector of human gene symbols
#'     where the names are the matching mouse gene symbols.  This
#'     requires eliminating duplicates
#' @export
mouseToHuman = function(mouseGenes)
{
    
    require("biomaRt")
    human = useMart("ensembl", dataset = "hsapiens_gene_ensembl")
    mouse = useMart("ensembl", dataset = "mmusculus_gene_ensembl")
    
    genesV2 = getLDS(attributes = c("mgi_symbol"),
                     filters = "mgi_symbol",
                     values = mouseGenes ,
                     mart = mouse,
                     attributesL = c("hgnc_symbol"),
                     martL = human, uniqueRows=T)

    genesV2 = genesV2[!duplicated(genesV2$MGI.symbol),]
    dictionary = genesV2$HGNC.symbol
    names(dictionary) = genesV2$MGI.symbol
    
    return(dictionary)
}


## ###################################################
#' For converting human genes to mouse genes
#'
#' This uses biomaRt to produce a dictionary from the given human
#' genes to their mouse equivalents.
#'
#' @param humanGenes - a character vector of human gene symbols
#'
#' @return This returns a named character vector of mouse gene symbols
#'     where the names are the matching human gene symbols.  This
#'     requires eliminating duplicates
#' @export
humanToMouse = function(humanGenes)
{
    
    require("biomaRt")
    human = useMart("ensembl", dataset = "hsapiens_gene_ensembl")
    mouse = useMart("ensembl", dataset = "mmusculus_gene_ensembl")
    
    genesV2 = getLDS(attributes = c("hgnc_symbol"),
                     filters = "hgnc_symbol",
                     values = humanGenes ,
                     mart = human,
                     attributesL = c("mgi_symbol"),
                     martL = mouse,
                     uniqueRows=T)

    genesV2 = genesV2[!duplicated(genesV2$HGNC.symbol),]
    dictionary = genesV2$MGI.symbol
    names(dictionary) = genesV2$HGNC.symbol
    
    return(dictionary)
}
