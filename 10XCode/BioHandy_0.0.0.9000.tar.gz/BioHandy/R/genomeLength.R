
## ###################################################
#' Total length of the genome
#'
#' This returns the total length of the genome.
#'
#' @param organism Currently only 'mouse'
#' @param goodChromosomes Use only chr.  Defaults to true
#' @return Returns the total length
#' @import TxDb.Mmusculus.UCSC.mm10.knownGene
#' @importFrom GenomeInfoDb seqlengths
#' @export
genomeLength = function(organism,goodChromosomes=TRUE)
{
    stopifnot(organism %in% c('mouse'))

    totalLength = sum(chromosomeLengths(organism,goodChromosomes))

    return(totalLength)
}


## ###################################################
#' Chromosome lengths
#'
#' This returns the lengths of the chromosomes.
#'
#' @param organism Currently only 'mouse'
#' @param goodChromosomes Use only chr.  Defaults to true
#' @return Returns the chomosome lengths
#' @export
chromosomeLengths = function(organism,goodChromosomes=TRUE)
{
    stopifnot(organism %in% c('mouse'))

    txdb = TxDb.Mmusculus.UCSC.mm10.knownGene
    if(goodChromosomes)
        txdb = setSeqlevels(txdb,organism)

    return(seqlengths(txdb))
}

              
