
#' This function jazzes up tic()
#'
#' This prints the string before invoking tic()  That way you
#' get to see the that you are starting the task.
#' @param msg The message, of course.
#'
#' @export


Tic = function(msg)
{
    writeLines(msg)
    tictoc::tic(msg)
}
