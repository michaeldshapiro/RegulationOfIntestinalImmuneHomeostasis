
#' For writing tables:
#'
#' This function writes a table with my standard options.
#' @param table The table.
#' @param tableName The file to save it to.
#' @param col.names Defaults to true.
#' @param row.names Defaults to false
#' @param xl Defaults to false.  If true, also saves file as excel
#'
#' @export

Write.Table = function(table,tableName,col.names=TRUE,row.names=FALSE,xl=FALSE)
{
    write.table(table,
                tableName,
                col.names=col.names,
                row.names=row.names,
                quote=FALSE,
                sep='\t')

    if(xl)
    {
        xlName = stringr::str_replace(tableName,'.txt' ,'.xlsx')
        xlsx::write.xlsx(table,xlName)
    }
}
