

#' For reading tables:
#'
#' This function reads a table with my standard options.
#' @param table The table.
#' @param header Defaults to true.
#'
#' @export



Read.Table = function(tableName,header=TRUE)
{
    df = read.table(tableName,
                    header=header,
                    sep='\t',
                    stringsAsFactors=FALSE)
    return(df)
}
